using Microsoft.EntityFrameworkCore;
using WebApplication2.ViewModel;

namespace order_ms.Infra
{
    public class FeedbackContext : DbContext
    {
        public DbSet<pupil> OrderData { get; set; }

        public FeedbackContext()
        {
        }

        public FeedbackContext(DbContextOptions
<FeedbackContext> options) : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=NAG6CHANDRVAR01; initial catalog=Feedback;integrated security=true;");
        }
    }
}
