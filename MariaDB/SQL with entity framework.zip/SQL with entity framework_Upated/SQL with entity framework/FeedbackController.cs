﻿using Microsoft.AspNetCore.Mvc;
using order_ms.Infra;
using System.Threading.Tasks;
using WebApplication2.Infra;
using WebApplication2.ViewModel;

namespace order_ms.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FeedbackContoller : ControllerBase
    {
        private readonly IFeedbackDataAccess.cs _orderDataAccess;

        public FeedbackContoller(
            IFeedbackDataAccess.cs FeedbackDataAccess)
        {
            _orderDataAccess = FeedbackDataAccess;
        }

        [HttpPost]
        [Route("createorder")]
        public async Task<IActionResult> CreateOrder([FromBody] pupil pupil)
        {
            _orderDataAccess.SaveOrder(pupil);

            return Ok("Success");
        }

        [HttpGet]
        [Route("getall")]
        public async Task<IActionResult> GetAll()
        {
            return Ok(_orderDataAccess.GetAllOrder());
        }
    }
}