﻿using System.Collections.Generic;
using System.Linq;
using WebApplication2.Infra;
using WebApplication2.ViewModel;

namespace order_ms.Infra
{
    public class FeedbackDataAccess : IFeedbackDataAccess.cs
    {
        public List<pupil> GetAllOrder()
        {
            using (var context = new FeedbackContext())
            {
                return context.OrderData.ToList();
            }
        }
        public void SaveOrder(pupil order)
        {
            using (var context = new FeedbackContext())
            {
                context.Add<pupil>(order);
                context.SaveChanges();
            }
        }
    }
}
