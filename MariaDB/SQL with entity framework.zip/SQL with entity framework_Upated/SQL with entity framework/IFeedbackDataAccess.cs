﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.ViewModel;

namespace WebApplication2.Infra
{
    public interface IFeedbackDataAccess.cs
    {
        List<pupil> GetAllOrder();

        void SaveOrder(pupil order);
    }
}
