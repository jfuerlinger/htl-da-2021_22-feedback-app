# HTL Leonding Diploma Thesis Template

Used by students to create their diploma thesis.

![HTBLA Leonding](titlepage/htlleondinglogo.png)